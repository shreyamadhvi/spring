/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.medical;

import java.util.List;

/**
 *
 * @author admin
 */
public interface Itemsdao {
    
    public void save(Items I);
     public void update(Items I);

 public List<Items> getItems();
 
 public Items getItemsByitemid(int itemid);
 
 public void delete(Items I);
}

