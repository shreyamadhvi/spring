/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.medical;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author admin
 */
public class Itemsdaoimpl implements Itemsdao {

    private JdbcTemplate jdbcTemplate;

    public Itemsdaoimpl(DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    
    
    
    
    
    
    
    
    
    
    
    
    
    @Override
    public void save(Items I) {
        String sql ="insert into inventory(Itemid,name,price,quantity,status)  values('"+I.getItemid()+"'  ,"+I.getName()+"  ,'"+I.getPrice()+"',  '"+I.getQuantity()+" ' ,'"+I.isStatus()+"'  )";  

        return jdbcTemplate.update(sql);
    }

    public int update(Items I) {
        String sql = "update inventory set itemid='" + I.getItemid() + "', name=" + I.getName() +
        ", price ='"+I.getPrice()+"'  ,quantity="+I.getQuantity()+"  ,status="+I.isStatus()+"  where itemid="+I.getItemid()+"  ";  

        return jdbcTemplate.update(sql);
    }

    public void delete(int itemid) {
        String sql = "delete from inventory where itemid=" + itemid + "";
        return jdbcTemplate.delete(sql);
    }

    @Override
    public Items getItemsByitemid(int itemid) {
        String sql = "select * from inventory where itemid=?";
        return jdbcTemplate.queryForObject(sql, new Object[]{itemid}, new BeanPropertyRowMapper<Items>(Items.class));
    }

    public List<Items> getItems() {
        return jdbcTemplate.query("select * from inventory", new RowMapper<Items>() {
            public Items mapRow(ResultSet rs, int row) throws SQLException {
                Items  M = new Items();
                M.setItemid(rs.getInt(1));
                M.setName(rs.getString(2));
                M.setPrice(rs.getDouble(3));
                M.setQuantity(rs.getInt(4));
                M.setStatus(rs.getBoolean(5));

                return M;
            }
        });
    }
}
