/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.teacher;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author admin
 */
@Controller
public class TeacherController {
   @RequestMapping(value = "/", method = RequestMethod.GET)
   public String callIndex(ModelMap model) {
      return "index";
   }
    
   @RequestMapping(value = "/teacher", method = RequestMethod.GET)
   public ModelAndView teacher() {
      return new ModelAndView("teacher", "command", new Teacher());
   }
   
   @RequestMapping(value = "/TeacherDetails", method = RequestMethod.POST)
   public String TeacherDetails(@ModelAttribute("SpringMVC")Teacher teacher, 
   ModelMap model) {
      model.addAttribute("Name", teacher.getName());
      model.addAttribute("Qualification", teacher.getQualification());
      model.addAttribute("TeachingSubject", teacher.getTeachingSubject());
      
      return "Teacherresult";
   }
    
}
