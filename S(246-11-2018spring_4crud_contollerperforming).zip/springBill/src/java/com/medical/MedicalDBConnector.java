/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.medical;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author admin
 */
public final class MedicalDBConnector {
    private final String url = "jdbc:mysql://localhost:3306/BillSystem?zeroDateTimeBehavior=convertToNull";
    private final String username = "root";
    private final String password = "mysql";
    private Connection connection = null;
    public MedicalDBConnector(){
        connection();
    }
    private void connection(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(url, username, password);          
        } catch (ClassNotFoundException ex) {
            System.out.println("CLASSERR : " + ex.getMessage());
        } catch (SQLException ex) {
            System.out.println("SQLERR : " + ex.getMessage());
        }
    }
    public void disconnect(Connection connection){
        try {
            connection.close();
        } catch (SQLException ex) {
            System.out.println("DBERROR : " + ex.getMessage());
        }
   }

    public Connection getConnection() {
        return connection;
    }
}
