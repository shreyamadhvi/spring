/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.medical;

import com.mysql.jdbc.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class Itemsdaoimpl implements Itemsdao {

    private Connection con;
    private MedicalDBConnector medicalDBConnector;
    private String sql = null;
    private PreparedStatement ps = null;
    private Statement st;
    private ResultSet rs;

    private void connect() {
        medicalDBConnector = new MedicalDBConnector();
        con = medicalDBConnector.getConnection();
    }

    private void disconnect() {
        try {
            medicalDBConnector.disconnect(con);
        } catch (Exception e) {
            System.out.println("DISERR : " + e.getMessage());
        }
    }

    public int save(Items item) {
        int status = 0;
        try {
            connect();
            sql = "insert into inventory(Itemid,name,price,quantity,status) values(?,?,?,?,?)";
            ps = (PreparedStatement) con.prepareStatement(sql);
            ps.setInt(1, item.getItemid());
            ps.setString(2, item.getName());
            ps.setDouble(3, item.getPrice());
            ps.setInt(4, item.getQuantity());
            ps.setInt(5, item.getStatus());
            status = ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("ITIDERR : " + e.getMessage());
        } finally {
            disconnect();
        }
        return status;
    }

    @Override
    public int update(Items item) {
         int status = 0;
          try {
            connect();
            sql = "update inventory set name = ?,price = ? ,quantity = ?,status = ? where Itemid = ?";
            ps = (PreparedStatement) con.prepareStatement(sql);
            ps.setString(1, item.getName());
            ps.setDouble(2, item.getPrice());
            ps.setInt(3, item.getQuantity());
            ps.setInt(4, item.getStatus());
            ps.setInt(5, item.getItemid());

            status = ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("UPDATEERR : " + e.getMessage());
        } finally {
            disconnect();
        }
        return status;    
        }

    @Override
    public int delete(Items item) {
         int status = 0;
          try {
            connect();
            sql = "delete from inventory where Itemid = ?";
            ps = (PreparedStatement) con.prepareStatement(sql);
            ps.setInt(1, item.getItemid());
            status = ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("DELETEERR : " + e.getMessage());
        } finally {
            disconnect();
        }
        return status; 
    }

    @Override
    public List<Items> getAllItems() {
        List<Items> itemList = new ArrayList<>();
        try {
            connect();
            sql = "select * from inventory";
            st = con.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()) {
                Items item = new Items();
                item.setItemid(rs.getInt(1));
                item.setName(rs.getString(2));
                item.setPrice(rs.getDouble(3));
                item.setQuantity(rs.getInt(4));
                item.setStatus(rs.getInt(5));
                itemList.add(item);
            }
        } catch (SQLException e) {
            System.out.println("ITIDERR : " + e.getMessage());
        } finally {
            disconnect();
        }
        return itemList;
    }

    @Override
    public Items getItemsByitemid(int itemid) {
        Items item = new Items();
        try {
            connect();
            sql = "select * from inventory where itemid=?";
            ps = (PreparedStatement) con.prepareStatement(sql);
            ps.setInt(1, itemid);
            rs = ps.executeQuery();
            if (rs.next()) {
                item.setItemid(rs.getInt(1));
                item.setName(rs.getString(2));
                item.setPrice(rs.getDouble(3));
                item.setQuantity(rs.getInt(4));
                item.setStatus(rs.getInt(5));
            }
        } catch (SQLException e) {
            System.out.println("ITIDERR : " + e.getMessage());
        } finally {
            disconnect();
        }
        return item;
    }

    public static void main(String[] args) {
        Itemsdaoimpl it = new Itemsdaoimpl();
//        for (int i = 0; i < 9; i++) {
//            System.out.println(it.getItemsByitemid(i));
//        }
        Items I =new Items(9,"sumiyt ",200.55,11,1);
        System.out.println(it.getAllItems());
        
        System.out.println("save data "+it.save(I));
        System.out.println("getItemsByitemid data"+it.getItemsByitemid(I.getItemid()));
        I =new Items(9,"shreya",300.25,11, 1);
        System.out.println(" update data "+it.update(I));
        System.out.println("getItemsByitemid data "+it.getItemsByitemid(I.getItemid()));
        System.out.println("delete data "+it.delete(I));
    }

//    
//
//    public Itemsdaoimpl(DataSource dataSource) {
//        jdbcTemplate = new JdbcTemplate(dataSource);
//    }
//
//    @Override
//    public void save(Items I) {
//        String sql = "insert into inventory(Itemid,name,price,quantity,status)  values('" + I.getItemid() + "'  ," + I.getName() + "  ,'" + I.getPrice() + "',  '" + I.getQuantity() + " ' ,'" + I.isStatus() + "'  )";
//
//        return jdbcTemplate.update(sql);
//    }
//
//    public int update(Items I) {
//        String sql = "update inventory set itemid='" + I.getItemid() + "', name=" + I.getName()
//                + ", price ='" + I.getPrice() + "'  ,quantity=" + I.getQuantity() + "  ,status=" + I.isStatus() + "  where itemid=" + I.getItemid() + "  ";
//
//        return jdbcTemplate.update(sql);
//    }
//
//    public void delete(int itemid) {
//        String sql = "delete from inventory where itemid=" + itemid + "";
//        return jdbcTemplate.delete(sql);
//    }
//
//    @Override
//    public Items getItemsByitemid(int itemid) {
//        String sql = "select * from inventory where itemid=?";
//        return jdbcTemplate.queryForObject(sql, new Object[]{itemid}, new BeanPropertyRowMapper<Items>(Items.class));
//    }
//
//    public List<Items> getItems() {
//        return jdbcTemplate.query("select * from inventory", new RowMapper<Items>() {
//            public Items mapRow(ResultSet rs, int row) throws SQLException {
//                Items M = new Items();
//                M.setItemid(rs.getInt(1));
//                M.setName(rs.getString(2));
//                M.setPrice(rs.getDouble(3));
//                M.setQuantity(rs.getInt(4));
//                M.setStatus(rs.getBoolean(5));
//
//                return M;
//            }
//        });
//    }
}
