/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.teacher;

/**
 *
 * @author admin
 */
public class Teacher {

    private String Name;
    private String Qualification;
    private String TeachingSubject;

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getQualification() {
        return Qualification;
    }

    public void setQualification(String Qualification) {
        this.Qualification = Qualification;
    }

    public String getTeachingSubject() {
        return TeachingSubject;
    }

    public void setTeachingSubject(String TeachingSubject) {
        this.TeachingSubject = TeachingSubject;
    }

}
