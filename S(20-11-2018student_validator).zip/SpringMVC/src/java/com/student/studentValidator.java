/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.student;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

/**
 *
 * @author admin
 */
public class studentValidator implements Validator {

   @Override
   public boolean supports(Class<?> clazz) {
      return Student.class.isAssignableFrom(clazz);
   }

   @Override
   public void validate(Object target, Errors errors) {		
      ValidationUtils.rejectIfEmptyOrWhitespace(errors, 
         "name", "required.name","Field name is required.");
      ValidationUtils.rejectIfEmptyOrWhitespace(errors, 
         "age", "required.age","Field age is required.");
      ValidationUtils.rejectIfEmptyOrWhitespace(errors, 
         "id", "required.id","Field id is required.");
   }
}