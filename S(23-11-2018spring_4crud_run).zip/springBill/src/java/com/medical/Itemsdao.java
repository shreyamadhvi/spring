/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.medical;

import java.util.List;

/**
 *
 * @author admin
 */
public interface Itemsdao {

    public int save(Items I);

    public int update(Items I);

    public int  delete(Items I);

    public List<Items> getAllItems();

    public Items getItemsByitemid(int itemid);

}
