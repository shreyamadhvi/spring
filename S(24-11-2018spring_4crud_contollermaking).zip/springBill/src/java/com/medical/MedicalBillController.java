/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.medical;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author admin
 */
@Controller
public class MedicalBillController {
       @RequestMapping(value = "/", method = RequestMethod.GET)
   public String callIndex(ModelMap model) {
      return "index";
   }
//    @RequestMapping(value = "/Items", method = RequestMethod.GET)
//   public ModelAndView Items() {
//      return new ModelAndView("Items", "command", new Items());
//   }
    @RequestMapping(value = "/itemList", method = RequestMethod.GET)
   public String getAllItems(ModelMap model) {
       model.addAllAttributes("itemList","command",new Items());
      return "itemList";
}
   
   @RequestMapping(value = "/save", method = RequestMethod.GET)
   public String save(ModelMap model) {
       model.save("save","command",new Items());
      return "save";
}
   
   @RequestMapping(value = "/update", method = RequestMethod.GET)
   public String update(ModelMap model) {
       model.update("itemList","command",new Items());
      return "itemList";
}
    @RequestMapping(value = "/delete", method = RequestMethod.GET)
   public String delete(ModelMap model) {
       model.delete("itemList","command",new Items());
      return "itemList";
}
    @RequestMapping(value = "/getItemsByitemid", method = RequestMethod.GET)
   public String getItemsByitemid(ModelMap model) {
       model.getItemsByitemid("itemList","command",new Items());
      return "itemList";
}
   
   
}